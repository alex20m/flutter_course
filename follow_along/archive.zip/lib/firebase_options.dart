import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default Firebase configuration for the app.
///
/// Replace placeholder values with values from your own FlutterFire config.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }

    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        return linux;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'REDACTED',
    appId: 'REDACTED',
    messagingSenderId: 'REDACTED',
    projectId: 'REDACTED',
    authDomain: 'REDACTED',
    storageBucket: 'REDACTED',
    measurementId: 'REDACTED',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'REDACTED',
    appId: 'REDACTED',
    messagingSenderId: 'REDACTED',
    projectId: 'REDACTED',
    storageBucket: 'REDACTED',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'REDACTED',
    appId: 'REDACTED',
    messagingSenderId: 'REDACTED',
    projectId: 'REDACTED',
    storageBucket: 'REDACTED',
    iosBundleId: 'REDACTED',
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'REDACTED',
    appId: 'REDACTED',
    messagingSenderId: 'REDACTED',
    projectId: 'REDACTED',
    storageBucket: 'REDACTED',
    iosBundleId: 'REDACTED',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'REDACTED',
    appId: 'REDACTED',
    messagingSenderId: 'REDACTED',
    projectId: 'REDACTED',
    authDomain: 'REDACTED',
    storageBucket: 'REDACTED',
    measurementId: 'REDACTED',
  );

  static const FirebaseOptions linux = FirebaseOptions(
    apiKey: 'REDACTED',
    appId: 'REDACTED',
    messagingSenderId: 'REDACTED',
    projectId: 'REDACTED',
    authDomain: 'REDACTED',
    storageBucket: 'REDACTED',
    measurementId: 'REDACTED',
  );
}